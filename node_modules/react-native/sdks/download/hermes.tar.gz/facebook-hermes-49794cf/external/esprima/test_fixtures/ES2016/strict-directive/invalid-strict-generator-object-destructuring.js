function *g({x, y}) { "use strict"; }
