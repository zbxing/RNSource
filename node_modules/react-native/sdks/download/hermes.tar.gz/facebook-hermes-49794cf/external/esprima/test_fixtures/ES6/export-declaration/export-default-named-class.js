export default class foo {}
