var {} = 0
