({a: this} = 0);
