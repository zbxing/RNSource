function f(...x) { "use strict"; }
